# Kisan 365 – Firebase Authentication Starter

This is a Kotlin Android starter for Firebase Email/Password authentication.
It is a clean starter package, not a patch to an existing app (the GitHub `main`
branch was empty when checked).

## Included
- Email/password sign-in
- Email/password account creation
- Sign-out
- Current-user session check
- Firebase ID-token retrieval example
- Basic error handling
- Authentication and security notes

## Firebase setup
1. Create/open your Firebase project.
2. Add an Android app using the package name `com.kisan365.app`.
3. Enable **Authentication → Sign-in method → Email/Password**.
4. Download `google-services.json` for this exact Android app.
5. Put `google-services.json` inside the `app/` folder (same level as `app/build.gradle.kts`).
   Do not paste its contents into source code.
6. In Firebase Console → Project settings → Your apps, verify the package name matches.

## Uploading to GitHub from a phone
1. Extract this ZIP on your phone.
2. Open the extracted `Kisan365_Firebase_Auth` folder.
3. In GitHub, open `sukhchainsingh7824-beep/Kisan-365` → `Add file` → `Upload files`.
4. Upload the extracted project files/folders while preserving their folder structure.
   Do not upload only the ZIP if you want GitHub to show the source files.
5. Add `google-services.json` separately inside `app/` only if the repository is private
   and you understand that Firebase client config is not a server secret. Never upload
   service-account JSON files, private keys, passwords, or API secrets.

## Important security notes
- Never hardcode user passwords or put them in Git.
- This app delegates password verification and token lifecycle to Firebase Authentication.
- The Firebase SDK persists the signed-in user's session; the app does not manually save
  the password or refresh token.
- `getIdToken(false)` asks Firebase for a current ID token. Firebase refreshes it when needed.
- Send ID tokens only over HTTPS and verify them on a trusted backend before authorizing
  sensitive operations.
- Firebase client configuration (`google-services.json`) is not equivalent to a service
  account private key. Keep service-account keys and Admin SDK credentials server-side.
- For production, add password reset, email verification, account deletion, and backend
  authorization rules as required.

## Build note
This is a starter Android Gradle project. Open/import it with a compatible Android build
environment and let Gradle sync. No Gradle wrapper binary is included in this ZIP.
