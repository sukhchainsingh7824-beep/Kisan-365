package com.kisan365.app

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import kotlinx.coroutines.tasks.await

/**
 * Firebase Authentication wrapper.
 *
 * Passwords are sent to Firebase Auth over the SDK's protected network flow.
 * Do not store passwords or manually persist Firebase refresh tokens.
 */
class AuthRepository(
    private val auth: FirebaseAuth = FirebaseAuth.getInstance()
) {
    val currentUser: FirebaseUser?
        get() = auth.currentUser

    suspend fun signIn(email: String, password: String): FirebaseUser {
        require(email.isNotBlank()) { "Enter your email address." }
        require(password.isNotEmpty()) { "Enter your password." }
        return auth.signInWithEmailAndPassword(email.trim(), password).await().user
            ?: error("Firebase sign-in returned no user.")
    }

    suspend fun createAccount(email: String, password: String): FirebaseUser {
        require(email.isNotBlank()) { "Enter your email address." }
        require(password.length >= 6) { "Password must be at least 6 characters." }
        return auth.createUserWithEmailAndPassword(email.trim(), password).await().user
            ?: error("Firebase account creation returned no user.")
    }

    suspend fun getIdToken(forceRefresh: Boolean = false): String {
        val user = auth.currentUser ?: error("You are not signed in.")
        return user.getIdToken(forceRefresh).await().token
            ?: error("Firebase did not return an ID token.")
    }

    fun signOut() {
        auth.signOut()
    }
}
