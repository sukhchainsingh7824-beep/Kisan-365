package com.kisan365.app

import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {
    private val auth by lazy { AuthRepository() }
    private lateinit var status: TextView
    private lateinit var emailInput: EditText
    private lateinit var passwordInput: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showLoginUi()
        showCurrentSession()
    }

    private fun showLoginUi() {
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(40, 40, 40, 40)
        }

        val heading = TextView(this).apply {
            text = "Kisan 365"
            textSize = 28f
            gravity = Gravity.CENTER
        }
        status = TextView(this).apply {
            text = "Sign in with your Firebase account"
            textSize = 14f
            setPadding(0, 20, 0, 20)
        }
        emailInput = EditText(this).apply {
            hint = "Email"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS
        }
        passwordInput = EditText(this).apply {
            hint = "Password"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }

        val signIn = Button(this).apply {
            text = "Login"
            setOnClickListener { signIn() }
        }
        val register = Button(this).apply {
            text = "Create account"
            setOnClickListener { createAccount() }
        }
        val logout = Button(this).apply {
            text = "Logout"
            setOnClickListener {
                auth.signOut()
                status.text = "Signed out."
            }
        }

        container.addView(heading)
        container.addView(status)
        container.addView(emailInput)
        container.addView(passwordInput)
        container.addView(signIn)
        container.addView(register)
        container.addView(logout)
        setContentView(container)
    }

    private fun signIn() {
        runAuthAction("Signing in…") {
            auth.signIn(emailInput.text.toString(), passwordInput.text.toString())
            status.text = "Login successful. Welcome to Kisan 365."
        }
    }

    private fun createAccount() {
        runAuthAction("Creating account…") {
            auth.createAccount(emailInput.text.toString(), passwordInput.text.toString())
            status.text = "Account created and signed in."
        }
    }

    private fun runAuthAction(progress: String, action: suspend () -> Unit) {
        status.text = progress
        lifecycleScope.launch {
            try {
                action()
                passwordInput.text?.clear()
            } catch (e: Exception) {
                status.text = e.localizedMessage ?: "Authentication failed. Please try again."
            }
        }
    }

    private fun showCurrentSession() {
        val user = auth.currentUser
        if (user != null) {
            status.text = "Already signed in: ${user.email ?: user.uid}"
        }
    }
}
