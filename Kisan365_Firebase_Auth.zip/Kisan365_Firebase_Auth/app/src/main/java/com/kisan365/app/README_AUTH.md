# Authentication flow

1. User enters email and password in `MainActivity`.
2. `MainActivity` calls `AuthRepository.signIn()` or `createAccount()`.
3. `AuthRepository` calls Firebase Authentication SDK.
4. Firebase verifies credentials and returns a `FirebaseUser` on success.
5. Firebase SDK maintains the signed-in session. `currentUser` is checked on app start.
6. When a trusted backend needs proof of identity, call `getIdToken()` and send the token
   over HTTPS. The backend must verify the token with Firebase Admin SDK before trusting it.
7. `signOut()` ends the local Firebase session.

## Credential and token handling
- The password is used for the sign-in/create-account request and is not saved by this app.
- Do not log passwords, ID tokens, or refresh tokens.
- The Firebase SDK manages session persistence and refresh-token lifecycle.
- ID tokens are short-lived identity assertions. Obtain them from `getIdToken()` when needed;
  do not hardcode or store a copied token.
- Never use a client-side check alone to authorize sensitive data or device commands.
- Enforce access in Firestore/Realtime Database Security Rules or a trusted backend.
